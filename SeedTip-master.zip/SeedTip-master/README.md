SeedTip
=======

Find your local farmers markets (U.S. only)

I threw this together to learn the Google Map API. The script will pull data from the <a href="http://search.ams.usda.gov/farmersmarkets/v1/svcdesc.html">USDA API</a> and use 
the <a href="https://developers.google.com/maps/documentation/javascript/tutorial">Google Maps API</a> to display the closest locations.

A basic, responsive front end is included.

See a live working sample at www.seedtip.com

<b>View the 4 part tutorial on YouTube</b><br>
Part 1 - https://www.youtube.com/watch?v=lVhDux1vmIU<br>
Part 2 - https://www.youtube.com/watch?v=ygNn7P-Fas4<br>
Part 3 - https://www.youtube.com/watch?v=vImMDfaqA2A<br>
Part 4 - https://www.youtube.com/watch?v=Hv76o8PEKwk<br>
